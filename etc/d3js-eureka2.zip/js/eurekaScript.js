function setDevice(who, nexturl)
{
	var formData = new FormData();
	var allUrl = "ajax_set_device.php";

	formData.append("device", who);

		$.ajax({
			url: allUrl,
			data: formData,
			contentType: false, 
			dataType: 'html',
			type: 'POST',
			processData: false,
			success: function(data){

			},
			error:function(xhr, status, error){
				alert("시스템에 문제가 있습니다. \n관리자에게 문의하시기 바랍니다. \n" + status + " : " + error);
			}
		});

}

				
function checkID()
{
	var formData = new FormData();
	var allUrl = "ajax_check_id.php";

	var id_obj = document.getElementById('userId');

	var regexp = /^[a-z0-9가-힣]{2,12}$/;
	if(!regexp.test(id_obj.value))
	{
		alert('아이디는 2~12자 사이의 영문(소문자),숫자,한글만 가능합니다.');
		return false;
	}

	formData.append("id", id_obj.value);

		$.ajax({
			url: allUrl,
			data: formData,
			contentType: false, 
			dataType: 'json',
			type: 'POST',
			processData: false,
			success: function(data){
				if(data.error == null)
				{
					var obj_ok = document.getElementById('ok_id_check');
					obj_ok.value = 'OK';
					alert(data.message);
				}else
				{
					alert(data.error);
				}
				
			},
			error:function(xhr, status, error){
				alert("시스템에 문제가 있습니다. \n관리자에게 문의하시기 바랍니다. \n" + status + " : " + error);
			}
		});	
}


function setPlatform(device, url)
{
	setDevice(device, url);
}

function checkErrorLogin()
{
	var form = document.loginForm;

	if(form.userID.value == '')
	{
		alert('아이디는 필수입력입니다.');
		form.userID.focus();
		return false;
	}
	if(form.userPass.value == '')
	{
		alert('비밀번호는 필수입력입니다.');
		form.userPass.focus();
		return false;
	}
}

function checkErrorInsertCat1()
{
	var form = document.catForm;

	if(form.title.value == '')
	{
		alert('대분류명을 입력하세요');
		form.title.focus();
		return false;
	}

	if(form.odr.value == '')
	{
		alert('배치순서를 입력하세요');
		form.odr.focus();
		return false;
	}


}

function checkErrorInsertCat2()
{
	var form = document.catForm;

	if(form.cat1.value == '0')
	{
		alert('대분류명를 선택하세요');
		form.cat1.focus();
		return false;
	}

	if(form.title.value == '')
	{
		alert('소분류명을 입력하세요');
		form.title.focus();
		return false;
	}

	if(form.odr.value == '')
	{
		alert('배치순서를 입력하세요');
		form.odr.focus();
		return false;
	}

	if(form.types.value == '0')
	{
		alert('메뉴 형태를 선택하세요.');
		form.types.focus();
		return false;
	}

	if(form.types.value == '1' || form.types.value =='2')
	{
		if(form.url.value == '')
		{
			alert('메뉴형태가 링크일 때, URL은 필수입니다.');
			form.url.focus();
			return false;
		}
	}
}

function checkErrorJoin()
{
	var form = document.memForm;

	if(checkIdBox() == false)
	{
		alert('아이디 중복 확인 버튼을 눌러주세요');
		return false;
	}

	var regexp = /^[a-z0-9가-힣]{2,12}$/;
	if(!regexp.test(form.id.value))
	{
		alert('아이디는 2~12자 사이의 영문(소문자),숫자,한글만 가능합니다.');
		form.id.focus();
		return false;
	}

	if(form.pass.value != form.pass2.value)
	{
		alert('입력한 두 비밀번호가 일치하지 않습니다.');
		form.pass.focus();
		return false;
	}

	regexp = /^[a-z0-9]{4,12}$/;
	
	if(!regexp.test(form.pass.value))
	{
		alert('비밀번호는 4~12자 사이의 영문,숫자만 가능합니다.');
		form.pass.focus();
		return false;
	}

	regexp = /^[0-9]{4}-[01][0-9]-[0123][0-9]$/;
	
	if(!regexp.test(form.birth.value))
	{
		alert('생년월일은 YYYY-MM-DD 형식입니다.');
		form.birth.focus();
		return false;
	}

	regexp = /^01[0]-[0-9]{3,4}-[0-9]{4}$/;
	
	if(!regexp.test(form.mobile.value))
	{
		alert('휴대전화는 010-0000-0000 형식입니다.');
		form.mobile.focus();
		return false;
	}

	if(form.position[1].checked == true || form.position[2].checked == true)
	{
		if(form.clubidx.value == '0')
		{
			alert('소속 클럽을 선택하세요');
			form.clubidx.focus();
			return false;
		}
	}

	if(form.position[3].checked == true || form.position[4].checked == true || form.position[5].checked == true)
	{
		if(form.postext.value == '')
		{
			alert('직책을 입력하세요.');
			form.postext.focus();
			return false;
		}
	}
}

function checkErrorInsertBoard()
{
	var form = document.manForm;

	if(form.name.value =='')
	{
		alert('게시판 명칭을 입력하세요.');
		form.name.focus();
		return false;
	}

	if(form.group_idx.value =='0')
	{
		alert('게시판 그룹을 선택하세요.');
		form.group_idx.focus();
		return false;
	}

	var regexp = /^[0-9]{1,3}$/;
	
	if(!regexp.test(form.lpp.value))
	{
		alert('라인/화면은 1000미만의 숫자만 가능합니다.');
		form.lpp.focus();
		return false;
	}

}


function checkIdBox()
{
	var id_check_obj = document.getElementById('ok_id_check');
	if(id_check_obj.value =='')
	{
		return false;
	}
	return true;
}

function initCheckIdBox()
{
	var id_check_obj = document.getElementById('ok_id_check');
	id_check_obj.value = '';	
}

function selectMenuTypes()
{
	var form = document.catForm;
	var url_tr = document.getElementById('url_tr');
	var html_tr = document.getElementById('html_tr');
	var htmlidx = document.getElementById('htmlidx');
	var bid = document.getElementById('bid');

	if(form.types.value == '1' || form.types.value == '2')
	{
		url_tr.style.display = '';
		html_tr.style.display = 'none';
	}
	if(form.types.value == '3' || form.types.value == '4')
	{
		
		html_tr.style.display = '';
		url_tr.style.display = 'none';

		if(form.types.value == '3')
		{
			bid.disabled = true;
			htmlidx.disabled = false;
			htmlidx.value = '0';
		} else if(form.types.value == 4)
		{
			bid.disabled = false;
			bid.value = '0';
			htmlidx.disabled = true;
		}
	}
}

function previewImage(img)
{
	var obj = document.getElementById('preview_div');
	obj.innerHTML = "<img src='"+img+"' style='width:50%;'>";
}

function showHideSubMenu(who)
{
	//alert(maxMenuCount1);
	var obj = document.getElementById('subMenuDiv'+who);
	for(var i=1; i<=maxMenuCount1; i++)
	{
		var objHide = document.getElementById('subMenuDiv'+i);
		if(i == who)
			objHide.style.display = '';
		else
			objHide.style.display = 'none';
	}
	obj.style.display = '';
}




function setDefaultBoardManager()
{
	var form = document.manForm;
	form.useflag.value = '1';
	form.wlevel.value = '1';
	form.rlevel.value = '1';
	form.usemsg.value = '1';
	form.usereply.value = '1';
	form.filecount.value = '2';
	form.fileext.value = 'jpg,jpeg,gif,png,hwp,doc,pdf';


	form.cssno.value = 'col-md-1 visible-md visible-lg text-center';
	form.cssstatus.value = 'col-md-1 col-sm-2 col-xs-2 ellipsis';
	form.csstitle.value = 'col-md-4 col-sm-7 col-xs-7 ellipsis';
	form.csswriter.value = 'col-md-2 col-sm-3 col-xs-3 ellipsis';
	form.cssfile.value = 'col-md-1 visible-md visible-lg text-center ellipsis';
	form.csstime.value = 'col-md-2 visible-md visible-lg text-center ellipsis';
	form.csshit.value = 'col-md-1 visible-md visible-lg text-center ellipsis';
	form.cssleft.value = 'col-xs-2 visible-xs visible-sm visible-md visible-lg';
	form.cssright.value = 'col-xs-10 visible-xs visible-sm visible-md visible-lg';

	form.lpp.value = '15';
}



// START ROLLING BANNER
	$(document).ready(function() {
 
                var $panel = $(".rolling_panel").find("ul");
 
                var itemWidth = $panel.children().outerWidth(); // 아이템 가로 길이
                var itemLength = $panel.children().length;      // 아이템 수
 
                // Auto 롤링 아이디
                var rollingId;
 
                auto();
 
                // 배너 마우스 오버 이벤트
                $panel.mouseover(function() {
                    clearInterval(rollingId);
                });
 
                // 배너 마우스 아웃 이벤트
                $panel.mouseout(function() {
                    auto();
                });
 
                // 이전 이벤트
                $("#prev").on("click", prev);
 
                $("#prev").mouseover(function(e) {
                    clearInterval(rollingId);
                });
 
                $("#prev").mouseout(auto);
 
                // 다음 이벤트
                $("#next").on("click", next);
 
                $("#next").mouseover(function(e) {
                    clearInterval(rollingId);
                });
 
                $("#next").mouseout(auto);
 
                function auto() {
 
                    // 2초마다 start 호출
                    rollingId = setInterval(function() {
                        start();
                    }, 3000);
                }
 
                function start() {
                    $panel.css("width", itemWidth * itemLength);
                    $panel.animate({"left": - itemWidth + "px"}, function() {
 
                        // 첫번째 아이템을 마지막에 추가하기
                        $(this).append("<li>" + $(this).find("li:first").html() + "</li>");
 
                        // 첫번째 아이템을 삭제하기
                        $(this).find("li:first").remove();
 
                        // 좌측 패널 수치 초기화
                        $(this).css("left", 0);
                    });
                }
 
                // 이전 이벤트 실행
                function prev(e) {
                    $panel.css("left", - itemWidth);
                    $panel.prepend("<li>" + $panel.find("li:last").html() + "</li>");
                    $panel.animate({"left": "0px"}, function() {
                        $(this).find("li:last").remove();
                    });
                }
 
                // 다음 이벤트 실행
                function next(e) {
                    $panel.animate({"left": - itemWidth + "px"}, function() {
                        $(this).append("<li>" + $(this).find("li:first").html() + "</li>");
                        $(this).find("li:first").remove();
                        $(this).css("left", 0);
                    });
                }
        });


	$(document).ready(function() {
                var $panel = $(".rolling_led").find("ul");
 
                var itemWidth = $panel.children().outerWidth(); // 아이템 가로 길이
                var itemLength = $panel.children().length;      // 아이템 수
 
                // Auto 롤링 아이디
                var rollingId;
 
                auto();
 
                // 배너 마우스 오버 이벤트
                $panel.mouseover(function() {
                    clearInterval(rollingId);
                });
 
                // 배너 마우스 아웃 이벤트
                $panel.mouseout(function() {
                    auto();
                });
 
                // 이전 이벤트
                $("#prev").on("click", prev);
 
                $("#prev").mouseover(function(e) {
                    clearInterval(rollingId);
                });
 
                $("#prev").mouseout(auto);
 
                // 다음 이벤트
                $("#next").on("click", next);
 
                $("#next").mouseover(function(e) {
                    clearInterval(rollingId);
                });
 
                $("#next").mouseout(auto);
 
                function auto() {
 
                    // 2초마다 start 호출
                    rollingId = setInterval(function() {
                        start();
                    }, 4000);
                }
 
                function start() {
                    $panel.css("width", itemWidth * itemLength);
                    $panel.animate({"left": - itemWidth + "px"}, function() {
 
                        // 첫번째 아이템을 마지막에 추가하기
                        $(this).append("<li>" + $(this).find("li:first").html() + "</li>");
 
                        // 첫번째 아이템을 삭제하기
                        $(this).find("li:first").remove();
 
                        // 좌측 패널 수치 초기화
                        $(this).css("left", 0);
                    });
                }
 
                // 이전 이벤트 실행
                function prev(e) {
                    $panel.css("left", - itemWidth);
                    $panel.prepend("<li>" + $panel.find("li:last").html() + "</li>");
                    $panel.animate({"left": "0px"}, function() {
                        $(this).find("li:last").remove();
                    });
                }
 
                // 다음 이벤트 실행
                function next(e) {
                    $panel.animate({"left": - itemWidth + "px"}, function() {
                        $(this).append("<li>" + $(this).find("li:first").html() + "</li>");
                        $(this).find("li:first").remove();
                        $(this).css("left", 0);
                    });
                }
            });




// END ROLLING BANNER

